package com.zybooks.matthewhaggardinventorymanagement;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.service.autofill.UserData;

public class UserDatabase extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "userDatabase.db";
    private static final int VERSION = 1;

    public UserDatabase (Context context){
        super (context, DATABASE_NAME, null, VERSION);
    }

    private static final class UserTable{
        private static final String TABLE = "users";
        private static final String COL_ID = "_id";
        private static final String COL_USERID = "userID";
        private static final String COL_PASSWORD = "password";
        private static final String COL_PERMISSION = "permission";
    }

    // Create User table with 3 columns
    @Override
    public void onCreate(SQLiteDatabase db){
        db.execSQL("create table " + UserTable.TABLE + " (" +
                UserTable.COL_ID + " integer primary key autoincrement, " +
                UserTable.COL_USERID + " text, " +
                UserTable.COL_PASSWORD + " text, " +
                UserTable.COL_PERMISSION + " text )");

    }

    // Drop table if new version is created
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion){
        db.execSQL("drop table if exists " + UserTable.TABLE);
        onCreate(db);
    }

    public Boolean insertData(String username, String password){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("userID", username);
        contentValues.put("password", password);
        long result = db.insert("users", null, contentValues);

        if (result == -1){
            return false;
        }

        else{
            return true;
        }
    }

    public Boolean checkUsername(String username){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("Select * from users where userID = ?", new String[] {username});

        if (cursor.getCount() > 0){
            return true;
        }

        else{
            return false;
        }
    }

    // TODO: Implement a method to check to check to see if the user has given permission for sms.
    // Check to see if the user has enabled permissions by selecting "yes" button.
    public Boolean checkPermission(String permission){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("Select * from users where permission = ?", new String[] {"yes"});

        if (cursor.toString() == "yes"){
            return true;
        }

        else{
            return false;
        }
    }

    public Boolean checkUserNamePassword(String username, String password){
        SQLiteDatabase db = this.getWritableDatabase();
        System.out.println("We are good so far");

        Cursor cursor = db.rawQuery("Select * from users where userID = ? and password = ?", new String[] {username, password});
        System.out.println("Cursor created");


        if (cursor.getCount() > 0){
            System.out.println("Should be returning true now");
            return true;
        }

        else{
            System.out.println("Should be returning false now.");
            return false;
        }
    }
}
