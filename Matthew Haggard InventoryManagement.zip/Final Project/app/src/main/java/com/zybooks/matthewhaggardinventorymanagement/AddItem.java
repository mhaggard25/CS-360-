package com.zybooks.matthewhaggardinventorymanagement;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

// This class controls the add item page functionality.
public class AddItem extends AppCompatActivity {
    EditText itemNumber, description, quantity;
    Button addItem;

    ItemDatabase itemDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_item_page);

        // set the variables to the appropriate components
        itemNumber = findViewById(R.id.editTextItemNumber);
        description = findViewById(R.id.editTextItemDescription);
        quantity = findViewById(R.id.editTextItemQuantity);

        // buttons on the page
        addItem = findViewById(R.id.addItemPageButton);

        // Database
        itemDatabase = new ItemDatabase(this);

        addItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                // Convert all of the variables to string format
                String itemNumberTXT = itemNumber.getText().toString();
                String descriptionTXT = description.getText().toString();
                String quantityTXT = quantity.getText().toString();

                Boolean checkAddItemData = itemDatabase.insertItemData(itemNumberTXT, descriptionTXT, quantityTXT);
                if (checkAddItemData == true){
                    Toast.makeText(AddItem.this, "New item added successfully", Toast.LENGTH_SHORT);

                    Intent intent = new Intent(getApplicationContext(), MainScreen.class);
                    startActivity(intent);
                }

                else{
                    Toast.makeText(AddItem.this, "New item NOT ADDED", Toast.LENGTH_SHORT);
                }
            }
        });

    }
}
