package com.zybooks.matthewhaggardinventorymanagement;

public class Permissions {
}
