package com.zybooks.matthewhaggardinventorymanagement;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TableLayout;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

// This is the main interface for the app. Here the user will be able to view the database of items.
// There are buttons on screen that allow the user to modify the contents of the database.
public class MainScreen extends AppCompatActivity {
    ItemDatabase itemDatabase;
    RecyclerView recyclerView;
    CardView cardView;

    FloatingActionButton button;

    private ArrayList<String> itemNumbers, itemDescriptions, itemQuantites;
    MyAdapter adapter;

    private TableLayout tableLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_screen);

        button = findViewById(R.id.actionButton);

        itemDatabase = new ItemDatabase(this);
        itemNumbers = new ArrayList<>();
        itemDescriptions = new ArrayList<>();
        itemQuantites = new ArrayList<>();

        recyclerView = findViewById(R.id.recycler_view);
        adapter = new MyAdapter(this, itemNumbers, itemDescriptions, itemQuantites);

        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        displayData();

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), AddItem.class);
                startActivity(intent);
            }
        });
    }

    private void displayData(){
        Cursor cursor = itemDatabase.getItemInformation();

        if (cursor.getCount() == 0){
            Toast.makeText(this, "Nothing to show", Toast.LENGTH_SHORT).show();
        }
        else{
            while(cursor.moveToNext()){
                itemNumbers.add(cursor.getString(1));
                itemDescriptions.add(cursor.getString(2));
                itemQuantites.add(cursor.getString(3));
            }
        }
    }
}