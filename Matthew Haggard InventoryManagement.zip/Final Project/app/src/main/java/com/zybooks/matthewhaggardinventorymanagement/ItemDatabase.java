package com.zybooks.matthewhaggardinventorymanagement;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class ItemDatabase extends SQLiteOpenHelper {
        private static final String DATABASE_NAME = "itemDatabase.db";
        private static final int VERSION = 1;

        public ItemDatabase (Context context){
            super (context, DATABASE_NAME, null, VERSION);
        }

        private static final class ItemTable{
            private static final String TABLE = "items";
            private static final String COL_ID = "_id";
            private static final String COL_ITEMNUMBER = "itemNumber";
            private static final String COL_DESCRIPTION = "description";
            private static final String COL_QUANTITY = "quantity";
        }

        // Create User table with 3 columns
        @Override
        public void onCreate(SQLiteDatabase db){
            db.execSQL("create table " + com.zybooks.matthewhaggardinventorymanagement.ItemDatabase.ItemTable.TABLE + " (" +
                    com.zybooks.matthewhaggardinventorymanagement.ItemDatabase.ItemTable.COL_ID + " integer primary key autoincrement, " +
                    com.zybooks.matthewhaggardinventorymanagement.ItemDatabase.ItemTable.COL_ITEMNUMBER + " text, " +
                    com.zybooks.matthewhaggardinventorymanagement.ItemDatabase.ItemTable.COL_DESCRIPTION + " text, " +
                    com.zybooks.matthewhaggardinventorymanagement.ItemDatabase.ItemTable.COL_QUANTITY + " text)");

        }

        // Drop table if new version is created
        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion){
            db.execSQL("drop table if exists " + com.zybooks.matthewhaggardinventorymanagement.ItemDatabase.ItemTable.TABLE);
            onCreate(db);
        }

        public Boolean insertItemData(String itemNumber, String itemDescription, String itemQuantity){
            SQLiteDatabase db = this.getWritableDatabase();
            ContentValues contentValues = new ContentValues();
            contentValues.put("itemNumber", itemNumber);
            contentValues.put("description", itemDescription);
            contentValues.put("quantity", itemQuantity);
            long result = db.insert("items", null, contentValues);

            if (result == -1){
                return false;
            }

            else{
                return true;
            }
        }

    public Boolean updateItemData(String itemNumber, String itemDescription, String itemQuantity) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("description", itemDescription);
        contentValues.put("quantity", itemQuantity);

        Cursor cursor = db.rawQuery("Select * from items where itemNumber = ?", new String[]{itemNumber});
        if (cursor.getCount() > 0) {
            long result = db.update("items", contentValues, "itemNumber=?", new String[]{itemNumber});

            if (result == -1) {
                return false;
            } else {
                return true;
            }
        } else {
            return false;
        }
    }

    public String getItemNumber(){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        String itemNumber = "";
        contentValues.put("itemNumber", itemNumber);
        Cursor cursor = db.rawQuery("Select * from items where itemNumber = ?", new String[]{itemNumber});

        return itemNumber;
    }

    public Boolean deleteItemData(String itemNumber) {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("Select * from items where itemNumber = ?", new String[]{itemNumber});

        if (cursor.getCount() > 0) {
            long result = db.delete("items", "itemNumber=?", new String[]{itemNumber});

            if (result == -1) {
                return false;
            }
            else {
                return true;
            }
        }
        else {
            return false;
        }
    }

    public Cursor getItemInformation() {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("Select * from items", null);

        return cursor;
    }

    // This function determines whether or not the database is empty. This is used for when the user logs in
    // and will determine which page the user will go to initially.
    public Boolean isDatabaseEmpty(){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.query("items", null, null, null, null, null, null);

        if (cursor.getCount() > 0){
            return false;
        }

        else{
            return true;
        }


    }




// This closing bracket is the end.
}
