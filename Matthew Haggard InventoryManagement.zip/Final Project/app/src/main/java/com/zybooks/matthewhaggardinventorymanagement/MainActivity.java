package com.zybooks.matthewhaggardinventorymanagement;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    // Declare variables
    UserDatabase database;
    ItemDatabase itemDatabase;
    Button signUpButton, loginButton;
    EditText username, password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Buttons and  on the login screen setup
        signUpButton = findViewById(R.id.signUpButton);
        loginButton = findViewById(R.id.loginButton);
        username = findViewById(R.id.editTextUsername);
        password = findViewById(R.id.editTextPassword);
        database = new UserDatabase(this);
        itemDatabase = new ItemDatabase(this);

        // What to do if login button pressed
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // convert username and password to string
                String user = username.getText().toString();
                String pass = password.getText().toString();

                // If nothing entered
                if (user.equals("") || pass.equals("")){
                    // Display message
                    Toast.makeText(MainActivity.this, "Please enter all fields", Toast.LENGTH_SHORT).show();
                }

                else{
                    // Check to see if user exists
                    Boolean checkUser = database.checkUsername(user);

                    // If user doesn't exist, inform user to press signup instead
                    if (!checkUser) {
                        Toast.makeText(MainActivity.this, "User not found. Please sign up.", Toast.LENGTH_SHORT).show();
                    }

                    else{
                        // login with the correct credentials
                        Boolean checkUserPass = database.checkUserNamePassword(user, pass);
                        if (checkUserPass){
                            Toast.makeText(MainActivity.this, "Login Successful", Toast.LENGTH_SHORT).show();

                            // If itemDatabase empty, go to the add item screen. Display toast message saying why
                            if (itemDatabase.isDatabaseEmpty() == true) {
                                Toast.makeText(MainActivity.this, "Database is empty. Please add an item.", Toast.LENGTH_SHORT).show();
                                Intent intent = new Intent(getApplicationContext(), AddItem.class);
                                startActivity(intent);
                            } else {
                                // If itemDatabase not empty, go to the main screen
                                Intent intent = new Intent(getApplicationContext(), MainScreen.class);
                                startActivity(intent);
                            }
                        }
                    }
                }
            }
        });

        // What to do if the sign up button is pressed
        signUpButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String user = username.getText().toString();
                String pass = password.getText().toString();

                // If nothing entered
                if (user.equals("") || pass.equals("")){
                    Toast.makeText(MainActivity.this, "Please enter all fields", Toast.LENGTH_SHORT).show();
                }

                else{
                    // Check to see if user exists
                    Boolean checkUser = database.checkUsername(user);

                    // If user doesn't exist, add user to the database
                    if (checkUser == false) {
                        Boolean insert = database.insertData(user, pass);

                        // Display message showing that user was created successfully.
                        if (insert == true){
                            Toast.makeText(MainActivity.this, "User created successfully", Toast.LENGTH_SHORT).show();

                            // TODO: Change to the next screen
                            Intent intent = new Intent(getApplicationContext(), MainScreen.class);
                            startActivity(intent);
                        }

                        else{
                            Toast.makeText(MainActivity.this, "Registration failed", Toast.LENGTH_SHORT).show();
                        }

                    }

                    else{
                        Toast.makeText(MainActivity.this, "User already exists. Please login.", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }
}